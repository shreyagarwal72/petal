package com.petal.browser.unit;

import static android.content.ContentValues.TAG;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Parcelable;
import android.provider.Settings;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.preference.PreferenceManager;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONException;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;

import java.util.ArrayList;

import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.regex.Pattern;

import com.petal.browser.R;
import com.petal.browser.activity.BrowserActivity;
import com.petal.browser.browser.List_standard;
import com.petal.browser.database.RecordAction;
import com.petal.browser.objects.CustomRedirect;
import com.petal.browser.objects.CustomRedirectsHelper;

public class BrowserUnit {

    public static final int LOADING_STOPPED = 101;  //Must be > PROGRESS_MAX !
    public static final String MIME_TYPE_TEXT_PLAIN = "text/plain";
    public static final String URL_ENCODING = "UTF-8";

    public static boolean isURL(String urlString) {
        if (urlString == null || urlString.trim().isEmpty()) {
            return false;
        }

        urlString = urlString.trim();
        // If string contains unencoded spaces, it's a search query, not a direct URL
        if (urlString.contains(" ")) {
            return false;
        }

        try {
            URI uri = new URI(urlString);

            // Fall 1: Die URL hat bereits ein explizites Schema
            if (uri.getScheme() != null) {
                String scheme = uri.getScheme().toLowerCase();
                // Erlaubt Web-Links sowie lokale Datei- und Inhalts-Pfade von Android
                return "http".equals(scheme) || "https".equals(scheme) || "file".equals(scheme) || "content".equals(scheme) || "about".equals(scheme) || "chrome".equals(scheme) || "moz-extension".equals(scheme) || "petal".equals(scheme);
            }

            // Fall 2: Die Eingabe hat kein Schema (z.B. "google.com")
            Pattern domainPattern = Pattern.compile("^[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}(/.*)?$");
            if (domainPattern.matcher(urlString).matches()) {
                URI fallbackUri = new URI("https://" + urlString);
                return fallbackUri.getHost() != null && fallbackUri.getHost().contains(".");
            }

            return false;
        } catch (URISyntaxException e) {
            return false;
        }
    }

    public static String queryWrapper(Context context, String query) {
        if (query == null || query.trim().isEmpty()) {
            return "";
        }
        query = query.trim();

        if (query.contains(";jsessionid=")) {
            String tracking = query.substring(query.lastIndexOf(";"));
            query = query.replace(tracking, "");
        }

        if (isURL(query)) {
            if (query.startsWith("about:blank") || query.startsWith("mailto:") || query.startsWith("file:") || query.startsWith("content:") || query.startsWith("chrome://") || query.startsWith("moz-extension://") || query.startsWith("petal://")) {
                return query;
            }
            if (!query.contains("://")) {
                query = "https://" + query;
            }
            return query;
        } else {
            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
            String customSearchEngine = sp.getString("sp_search_engine_custom", "");
            String customSearches = sp.getString("sp_search_customSearches", "");
            
            String encodedQuery;
            try {
                encodedQuery = URLEncoder.encode(query, "UTF-8");
            } catch (Exception e) {
                encodedQuery = query.replace(" ", "+");
            }

            if (!customSearches.isEmpty()) {
                return customSearches + encodedQuery;
            } else if (sp.getBoolean("searchEngineSwitch", false) && !customSearchEngine.isEmpty()) {
                return customSearchEngine + encodedQuery;
            } else {
                int i = 0;
                try {
                    i = Integer.parseInt(Objects.requireNonNull(sp.getString("sp_search_engine", "0")));
                } catch (Exception ignored) {}

                switch (i) {
                    case 0:
                        return "https://www.google.com/search?q=" + encodedQuery;
                    case 1:
                        return "https://duckduckgo.com/?q=" + encodedQuery;
                    case 2:
                        return "https://search.brave.com/search?q=" + encodedQuery;
                    case 3:
                        return "https://www.bing.com/search?q=" + encodedQuery;
                    case 4:
                        return "https://www.ecosia.org/search?q=" + encodedQuery;
                    default:
                        return "https://www.google.com/search?q=" + encodedQuery;
                }
            }
        }
    }

    public static void download(final Context context, final String url, final String fileName, final String mimeType) {
        if (context == null || url == null || url.trim().isEmpty()) {
            return;
        }
        // Sicherstellen, dass das Protokoll für den Android-Uri-Parser passt
        String verifiedUrl = url;
        if (!url.toLowerCase(Locale.US).startsWith("http://") && !url.toLowerCase(Locale.US).startsWith("https://")) {
            verifiedUrl = "https://" + url;
        }

        // If user set external download manager as preferred in Settings, redirect to external manager
        if (com.petal.browser.unit.ExternalDownloadManagerHelper.isExternalPreferred(context)) {
            boolean launched = com.petal.browser.unit.ExternalDownloadManagerHelper.launchDownloadInExternalManager(
                    context, verifiedUrl, fileName, mimeType, null
            );
            if (launched) {
                return;
            }
        }

        // Berechtigungsprüfung (Ab Android 10/Q wird WRITE_EXTERNAL_STORAGE für Downloads nicht mehr benötigt)
        boolean hasPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q || BackupUnit.checkPermissionStorage(context);
        if (hasPermission) {
            try {
                String userAgent = WebSettings.getDefaultUserAgent(context);
                CookieManager cookieManager = CookieManager.getInstance();
                String cookie = cookieManager.getCookie(verifiedUrl);

                java.util.Map<String, String> extraHeaders = new java.util.HashMap<>();
                extraHeaders.put("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8");
                extraHeaders.put("Accept-Language", Locale.getDefault().toLanguageTag());
                // Do NOT set a custom Accept-Encoding header here. HttpURLConnection (used by
                // Fetch2's HttpUrlConnectionDownloader) only performs transparent gzip
                // decompression when the app does not set this header itself. Setting it
                // manually (as before, "gzip, deflate, br, identity") tells the server it's
                // free to compress the response, but Fetch2 then writes the raw compressed
                // bytes straight to disk without decoding them - so a downloaded "file.zip"
                // was actually a gzip/br-compressed stream and failed to open as a valid zip.
                // Leaving Accept-Encoding unset lets the platform negotiate and decode gzip
                // transparently, so downloaded files (zip, pdf, images, etc.) land on disk intact.
                extraHeaders.put("Connection", "keep-alive");
                extraHeaders.put("Cache-Control", "no-transform");
                extraHeaders.put("Referer", verifiedUrl);

                // Petal Unified Best Download Engine:
                // High-speed parallel multi-threaded chunked downloader (Fetch2 + OkHttp),
                // with auto-retry on reconnects, safe RFC 5987 filename sanitization,
                // and real-time live alert progress tracking.
                com.petal.browser.download.PetalDownloadEngine.getInstance(context).enqueueDownload(
                        context, verifiedUrl, fileName, userAgent, cookie, extraHeaders,
                        (fetchId, resolvedName) -> com.petal.browser.compose.downloads.PetalLiveAlertManager.trackDownload(
                                context, fetchId.longValue(), resolvedName)
                );
            } catch (Exception e) {
                // Sicherer Umgang mit Fehlermeldungen ohne StringIndexOutOfBoundsException
                String errorMessage = e.getMessage() != null ? e.getMessage() : e.toString();
                Toast.makeText(context, context.getString(R.string.app_error) + ": " + errorMessage, Toast.LENGTH_LONG).show();
                Log.e(TAG, "Petal: Error Downloading File", e);
            }
        } else {
            // Sicherer Cast zu Activity nur, wenn der Context tatsächlich eine ist
            if (context instanceof Activity) {
                BackupUnit.requestPermission((Activity) context);
            } else {
                Log.e(TAG, "Cannot request permission: Context is not an Activity");
            }
        }
    }

    public static void clearBookmark(Context context) {
        RecordAction action = new RecordAction(context);
        action.open(true);
        action.clearTable(RecordUnit.TABLE_BOOKMARK);
        action.close();
    }

    public static void clearHistory(Context context) {
        RecordAction action = new RecordAction(context);
        action.open(true);
        action.clearTable(RecordUnit.TABLE_HISTORY);
        action.close();
    }

    public static void clearOnExit(Context context) {
        if (context == null) return;
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        boolean clearQuit = sp.getBoolean("sp_clear_quit", false) || sp.getBoolean("sp_clear_on_exit", false);
        if (!clearQuit) return;

        boolean clearHistory = sp.getBoolean("sp_clear_history", false);
        boolean clearCache = sp.getBoolean("sp_clear_cache", false);

        // 1. History cleanup: full history table if clearHistory is true, otherwise session-scoped history
        if (clearHistory) {
            BrowserUnit.clearHistory(context);
        }
        PetalSessionHistoryManager.clearSessionHistory(context);

        // 2. Clear render & disk cache if explicitly enabled OR when clear on exit is active
        if (clearCache || clearQuit) {
            try {
                CacheManager.clearAllCache(context, null);
            } catch (Exception exception) {
                Log.w("browser", "Error clearing cache on exit", exception);
            }
        }

        // 3. Clear session tab thumbnails and reset open tabs state
        try {
            TabThumbnailCache.evictAll();
        } catch (Exception ignored) {}
        try {
            sp.edit().putString("openTabs", "").apply();
        } catch (Exception ignored) {}

        // Note: NEVER remove account logins, Google credentials, saved passwords, or auth tokens on exit.
    }

    public static void clearBrowserData(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        boolean clearCache = sp.getBoolean("sp_clear_cache", false);
        boolean clearCookie = sp.getBoolean("sp_clear_cookie", false);
        boolean clearHistory = sp.getBoolean("sp_clear_history", false);
        boolean clearIndexedDB = sp.getBoolean("sp_clearIndexedDB", false);
        boolean clearDB = sp.getBoolean("sp_deleteDatabase", false);
        boolean clearSettings = sp.getBoolean("sp_clear_settings", false);

        if (clearHistory) BrowserUnit.clearHistory(context);
        if (clearCache)  {
            try {
                CacheManager.clearAllCache(context, null);
            } catch (Exception exception) {
                Log.w("browser", "Error clearing cache", exception);
            }
        }
        if (clearSettings) {
            clearSettingsSafely(sp);
            List_standard listStandard = new List_standard(context);
            listStandard.clearDomains();
        }
        // ONLY clear cookies and logins if the user explicitly commanded manual cookie deletion
        if (clearCookie) {
            CookieManager cookieManager = CookieManager.getInstance();
            cookieManager.flush();
            cookieManager.removeAllCookies(value -> {
            });
        }
        if (clearDB) {
            context.deleteDatabase("Ninja4.db");
            context.deleteDatabase("item_icon.db");
            sp.edit().putInt("restart_changed", 1).apply();
        }
        if (clearIndexedDB) {
            // Use WebStorage instead of raw app_webview file deletion while tabs are open
            try {
                WebStorage.getInstance().deleteAllData();
            } catch (Exception ignored) {}
        }
    }

    public static void clearSettingsSafely(SharedPreferences sp) {
        if (sp == null) return;
        java.util.Map<String, ?> all = sp.getAll();
        java.util.Map<String, Object> protectedMap = new java.util.HashMap<>();
        for (java.util.Map.Entry<String, ?> entry : all.entrySet()) {
            String key = entry.getKey();
            if (key != null && (
                key.contains("api_key") ||
                key.contains("account") ||
                key.contains("auth") ||
                key.contains("token") ||
                key.contains("login") ||
                key.contains("pass") ||
                key.contains("credential") ||
                key.contains("sync") ||
                key.contains("email") ||
                key.contains("profile") ||
                key.startsWith("sp_gemini") ||
                key.startsWith("sp_openrouter") ||
                key.startsWith("sp_openai") ||
                key.startsWith("sp_grok") ||
                key.startsWith("sp_groq") ||
                key.startsWith("sp_google") ||
                key.startsWith("sp_user_") ||
                key.startsWith("sp_custom_font") ||
                key.startsWith("sp_custom_")
            )) {
                protectedMap.put(key, entry.getValue());
            }
        }

        SharedPreferences.Editor editor = sp.edit().clear();
        for (java.util.Map.Entry<String, Object> entry : protectedMap.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (value instanceof String) {
                editor.putString(key, (String) value);
            } else if (value instanceof Boolean) {
                editor.putBoolean(key, (Boolean) value);
            } else if (value instanceof Integer) {
                editor.putInt(key, (Integer) value);
            } else if (value instanceof Long) {
                editor.putLong(key, (Long) value);
            } else if (value instanceof Float) {
                editor.putFloat(key, (Float) value);
            }
        }
        editor.apply();
    }

    public static void intentURL(Context context, Uri uri) {
        if (context == null || uri == null) return;
        String uriStr = uri.toString();
        if (uriStr.startsWith("petal://settings") || uriStr.startsWith("petal://credits")) {
            if (context instanceof Activity) {
                Activity activity = (Activity) context;
                if (uriStr.startsWith("petal://settings")) {
                    if (activity instanceof com.petal.browser.activity.BrowserActivity) {
                        if (uriStr.contains("category=api_integrations") || uriStr.contains("category=ai_research")) {
                            ((com.petal.browser.activity.BrowserActivity) activity).openApiIntegrationsHub();
                        } else {
                            ((com.petal.browser.activity.BrowserActivity) activity).openSettingsScreen();
                        }
                    } else {
                        Intent intent = new Intent(activity, com.petal.browser.activity.Settings_Activity.class);
                        if (uriStr.contains("category=api_integrations") || uriStr.contains("category=ai_research")) {
                            intent.putExtra(
                                com.petal.browser.activity.Settings_Activity.EXTRA_SETTINGS_CATEGORY,
                                com.petal.browser.compose.settings.SettingsCategory.API_INTEGRATIONS.name()
                            );
                        }
                        activity.startActivity(intent);
                    }
                    return;
}
        }
    }

}
    public static String redirectURL(SharedPreferences sp, String url) {
        if (url == null) return null;
        try {
            List<CustomRedirect> redirects = CustomRedirectsHelper.getRedirects(sp);
            for (CustomRedirect redirect : redirects) {
                if (redirect != null && redirect.getSource() != null && redirect.getTarget() != null &&
                        url.contains(redirect.getSource()) && sp != null && sp.getBoolean(redirect.getSource(), true)) {
                    return url.replace(redirect.getSource(), redirect.getTarget());
                }
            }
        } catch (Exception e) { Log.e("Redirect error", e.toString()); }
        return url;
    }

    public static boolean isHomePage(String url) {
        if (url == null || url.trim().isEmpty()) return true;
        String clean = url.trim().toLowerCase(Locale.ROOT);
        return clean.equals("about:blank") || clean.equals("about:home") ||
                clean.equals("petal://home") || clean.equals("petal://start") ||
                clean.contains("petal_home.html") || clean.startsWith("file:///android_asset/");
    }

}